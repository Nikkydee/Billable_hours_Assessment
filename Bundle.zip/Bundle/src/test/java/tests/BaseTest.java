package tests;

import com.google.common.io.Files;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.events.EventFiringWebDriverFactory;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServerHasNotBeenStartedLocallyException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
//import utils.AppiumListners;

import java.io.File;
import java.io.IOException;

public class BaseTest {
    protected static AndroidDriver driver;
    private static AppiumDriverLocalService service;

    /**
     * initialization.
     */
    @BeforeClass
    public static void AndroidSetUp() {
        service = AppiumDriverLocalService.buildDefaultService();
        service.start();
        if (service == null || !service.isRunning()) {
            throw new AppiumServerHasNotBeenStartedLocallyException(
                    "An appium server node is not started!");
        }

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability("appPackage", "com.bundle.billable_hours_app");
        capabilities.setCapability("appActivity", "com.bundle.billable_hours_app.MainActivity");
//        capabilities.setCapability(MobileCapabilityType.APP, System.getProperty("user.dir") + "/resources/apps/");
//        capabilities.setCapability("mjpegScrenshotUrl", "http://172.20.10.4:8080/stream.mjpeg");
        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
        capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
        capabilities.setCapability("eventTimings", true);
//        capabilities.setCapability("unicodeKeyboard", true);
//        capabilities.setCapability("resetKeyboard", true);
        capabilities.setCapability("autoGrantPermissions", true);
        driver = new AndroidDriver<AndroidElement>(service.getUrl(), capabilities);
//        driver = EventFiringWebDriverFactory.getEventFiringWebDriver(driver, new AppiumListners());
    }

    /**
     * finishing.
     */
    @AfterClass
    public static void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        if (service != null) {
            service.stop();
        }
    }

//    @AfterMethod
//    public void recordFailure(ITestResult result) {
//        if (ITestResult.FAILURE == result.getStatus()) {
//            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//            try {
//                Files.move(screenshot, new File("resources/screenshots/" + result.getName() + ".jpeg"));
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
