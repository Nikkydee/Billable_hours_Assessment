package tests;

import org.testng.annotations.Test;
import pages.CompanyPage;
import pages.HomePage;

public class HomePageTest extends BaseTest {

    @Test
    public void passFile(){
        HomePage homePage = new HomePage(driver);
        homePage.getFilePathField("/storage/emulated/0/Download/test.csv");
        CompanyPage companyPage = homePage.clickButton();
    }
}
