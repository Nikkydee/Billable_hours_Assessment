package pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import pages.CompanyPage;

import java.time.Duration;

public class HomePage {
    private AndroidDriver driver;

    @AndroidFindBy(xpath = "//android.widget.EditText[@index='2']")
    private WebElement filePathField;

    @AndroidFindBy(accessibility = "Continue")
    private WebElement continueButton;

    public HomePage(AndroidDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(15)), this);
    }

    public WebElement getFilePathField(String path) {
        filePathField.sendKeys(path);
        return filePathField;
    }

    public CompanyPage clickButton() {
        continueButton.click();
        return new CompanyPage(driver);
    }
}
